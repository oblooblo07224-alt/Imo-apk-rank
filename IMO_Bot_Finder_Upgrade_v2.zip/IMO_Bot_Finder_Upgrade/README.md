# IMO Bot Finder v2.0 — Win Streak & Push Rank Assistant

Android Kotlin MVP untuk mencatat hasil pertandingan MLBB dan memberi ringkasan performa. Dirancang untuk pemain yang push dari Legend dengan fokus Mid Lane menuju Mythical Immortal.

## Fitur
- Win streak / lose streak berdasarkan urutan match yang dicatat.
- Win rate keseluruhan dan jumlah match.
- Rata-rata K/D/A dan jumlah MVP yang dicatat.
- Statistik khusus Mid Lane.
- Rekap sederhana hero yang memiliki win rate tertinggi (minimal 2 match tercatat).
- Rekomendasi berbasis aturan: evaluasi setelah kalah beruntun, jaga konsistensi saat menang, dan saran dasar rotasi Mid Lane.
- Penyimpanan lokal menggunakan SharedPreferences; tidak ada izin internet atau akun MLBB.

## Build APK
1. Ekstrak ZIP.
2. Buka folder proyek `IMO_Bot_Finder_Upgrade` melalui Android Studio.
3. Gunakan JDK 17 dan Android SDK Platform 35. Tunggu Gradle Sync.
4. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK debug umumnya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Konfigurasi: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, minSdk 23, targetSdk 35, version 2.0.

## Catatan batasan
- Ini adalah tracker dan rekomendasi, bukan sistem yang menjamin win streak.
- Data dimasukkan oleh pengguna; aplikasi belum membaca pertandingan langsung atau mengimpor screenshot.
- Tidak mendeteksi bot dengan pasti, tidak mengakses server Moonton, dan tidak mengubah matchmaking.
- Statistik hero dengan sedikit sampel bisa menyesatkan; gunakan setidaknya 10–20 match untuk melihat pola awal.

## Build APK otomatis melalui GitHub Actions
Folder `.github/workflows/build-apk.yml` disertakan. Setelah mengunggah proyek ke repository GitHub, buka tab **Actions**, pilih **Build IMO Bot Finder APK**, lalu klik **Run workflow**. Setelah job sukses, unduh artifact `IMO-Bot-Finder-debug-apk` dari halaman run. Ini memerlukan akun GitHub dan build online; belum menghasilkan APK secara lokal.

package com.imo.botfinder

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 20)
    private val panel = Color.rgb(30, 30, 38)
    private val red = Color.rgb(255, 77, 77)
    private val green = Color.rgb(89, 210, 145)
    private val white = Color.rgb(245, 245, 248)
    private val muted = Color.rgb(180, 180, 192)
    private val prefs by lazy { getSharedPreferences("imo_history_v2", MODE_PRIVATE) }
    private lateinit var historyBox: LinearLayout
    private lateinit var dashboardBox: LinearLayout
    private lateinit var recommendationBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 28)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("IMO BOT FINDER", 27f, white, true))
        root.addView(text("WIN STREAK • SMART RANK ANALYZER", 13f, red, true).margins(0, 0, 0, 14))

        val disclaimer = card(root)
        disclaimer.addView(text("Pendamping push rank", 18f, white, true))
        disclaimer.addView(text(
            "Versi 2.0 • Data disimpan di perangkat. Aplikasi tidak terhubung ke server MLBB dan tidak bisa menjamin win streak atau mendeteksi bot secara pasti.",
            13f, muted, false
        ))

        dashboardBox = card(root)
        dashboardBox.addView(text("DASHBOARD", 18f, white, true))
        dashboardBox.addView(text("Memuat statistik...", 14f, muted, false))

        recommendationBox = card(root)
        recommendationBox.addView(text("REKOMENDASI PUSH RANK", 18f, white, true))

        val form = card(root)
        form.addView(text("CATAT PERTANDINGAN", 18f, white, true))
        form.addView(text("Isi setelah selesai bermain untuk memperbarui win streak dan analisis.", 13f, muted, false))

        val note = edit("Nama hero (contoh: Kagura)")
        val duration = edit("Durasi match (menit)")
        val kills = edit("Kill")
        val deaths = edit("Death")
        val assists = edit("Assist")
        form.addView(note); form.addView(duration); form.addView(kills); form.addView(deaths); form.addView(assists)

        form.addView(text("Role", 14f, white, true))
        val roleSpinner = spinner(listOf("Mid Lane", "Jungler", "Gold Lane", "EXP Lane", "Roamer"))
        roleSpinner.setSelection(0)
        form.addView(roleSpinner)

        form.addView(text("Hasil pertandingan", 14f, white, true).margins(0, 8, 0, 0))
        val resultSpinner = spinner(listOf("Menang", "Kalah"))
        form.addView(resultSpinner)

        val mvp = CheckBox(this).apply {
            text = "MVP / performa terbaik tim"
            textSize = 14f
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
        }
        form.addView(mvp)

        val save = Button(this).apply {
            text = "SIMPAN & ANALISIS"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
        }
        form.addView(save, lp().apply { topMargin = 12 })

        historyBox = card(root)
        historyBox.addView(text("RIWAYAT PERTANDINGAN", 18f, white, true))
        save.setOnClickListener {
            val hero = note.text.toString().trim().ifBlank { "Hero tidak dicatat" }
            val mins = duration.text.toString().toIntOrNull()
            val k = kills.text.toString().toIntOrNull()
            val d = deaths.text.toString().toIntOrNull()
            val a = assists.text.toString().toIntOrNull()
            if (mins == null || mins <= 0 || k == null || k < 0 || d == null || d < 0 || a == null || a < 0) {
                Toast.makeText(this, "Isi durasi, kill, death, dan assist dengan angka valid.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val win = resultSpinner.selectedItemPosition == 0
            val item = JSONObject().apply {
                put("hero", hero)
                put("duration", mins)
                put("kills", k)
                put("deaths", d)
                put("assists", a)
                put("role", roleSpinner.selectedItem.toString())
                put("win", win)
                put("mvp", mvp.isChecked)
                put("time", System.currentTimeMillis())
            }
            val arr = JSONArray(prefs.getString("matches", "[]"))
            arr.put(item)
            prefs.edit().putString("matches", arr.toString()).apply()
            note.setText(""); duration.setText(""); kills.setText(""); deaths.setText(""); assists.setText("")
            mvp.isChecked = false
            refreshAll()
            Toast.makeText(this, "Pertandingan tersimpan.", Toast.LENGTH_SHORT).show()
        }
        refreshAll()
    }

    private fun refreshAll() {
        if (!::dashboardBox.isInitialized) return
        val arr = JSONArray(prefs.getString("matches", "[]"))
        var wins = 0
        var losses = 0
        var streak = 0
        var streakIsWin = true
        var totalK = 0
        var totalD = 0
        var totalA = 0
        var mvpCount = 0
        var midGames = 0
        var midWins = 0
        var heroWins = HashMap<String, Int>()
        var heroGames = HashMap<String, Int>()
        for (i in 0 until arr.length()) {
            val x = arr.optJSONObject(i) ?: continue
            val win = x.optBoolean("win")
            if (win) wins++ else losses++
            totalK += x.optInt("kills")
            totalD += x.optInt("deaths")
            totalA += x.optInt("assists")
            if (x.optBoolean("mvp")) mvpCount++
            val role = x.optString("role")
            if (role == "Mid Lane") {
                midGames++
                if (win) midWins++
            }
            val hero = x.optString("hero", "Unknown")
            heroGames[hero] = (heroGames[hero] ?: 0) + 1
            if (win) heroWins[hero] = (heroWins[hero] ?: 0) + 1
        }
        if (arr.length() > 0) {
            val latest = arr.optJSONObject(arr.length() - 1)!!
            streakIsWin = latest.optBoolean("win")
            for (i in arr.length() - 1 downTo 0) {
                val x = arr.optJSONObject(i) ?: continue
                if (x.optBoolean("win") == streakIsWin) streak++ else break
            }
        }
        val total = wins + losses
        val wr = if (total > 0) wins * 100 / total else 0
        dashboardBox.removeAllViews()
        dashboardBox.addView(text("DASHBOARD", 18f, white, true))
        dashboardBox.addView(text("Match: $total   •   Menang: $wins   •   Kalah: $losses", 15f, white, true))
        dashboardBox.addView(text("Win rate: $wr%", 23f, if (wr >= 50) green else red, true))
        val streakLabel = if (streakIsWin) "WIN STREAK" else "LOSE STREAK"
        dashboardBox.addView(text("$streakLabel: $streak", 18f, if (streakIsWin) green else red, true))
        dashboardBox.addView(text(
            "Rata-rata K/D/A: ${avg(totalK,total)} / ${avg(totalD,total)} / ${avg(totalA,total)} • MVP: $mvpCount",
            13f, muted, false
        ))

        recommendationBox.removeAllViews()
        recommendationBox.addView(text("REKOMENDASI PUSH RANK", 18f, white, true))
        val advice = when {
            total == 0 -> "Mulai catat match. Setelah beberapa pertandingan, statistikmu akan lebih berguna."
            !streakIsWin && streak >= 2 -> "Kamu kalah $streak kali beruntun. Pertimbangkan istirahat 10–15 menit, lalu evaluasi draft dan objektif sebelum antre lagi."
            !streakIsWin && streak == 1 -> "Evaluasi satu kekalahan: posisi saat team fight, map awareness, dan objektif. Jangan buru-buru menyimpulkan matchmaking."
            streakIsWin && streak >= 3 -> "Kamu sedang win streak $streak! Pertahankan hero/role yang nyaman, tetap cek draft, dan berhenti saat lelah."
            wr < 50 && total >= 5 -> "Win rate di bawah 50% dari data yang dicatat. Fokus pada hero pool kecil, rotasi Mid Lane, bantu Turtle, dan review kekalahan."
            else -> "Jaga konsistensi: clear wave Mid Lane lebih dulu, rotasi ke side lane, cek minimap, dan bantu objektif. Catat minimal 10 match untuk melihat tren."
        }
        recommendationBox.addView(text(advice, 14f, white, false))
        val midWr = if (midGames > 0) midWins * 100 / midGames else 0
        recommendationBox.addView(text("Mid Lane: $midWins menang dari $midGames match ($midWr%).", 14f, muted, false))
        val bestHero = heroGames.keys
            .filter { (heroGames[it] ?: 0) >= 2 }
            .maxByOrNull { h -> (heroWins[h] ?: 0).toDouble() / (heroGames[h] ?: 1) }
        if (bestHero != null) {
            val hGames = heroGames[bestHero] ?: 0
            val hWins = heroWins[bestHero] ?: 0
            recommendationBox.addView(text(
                "Hero dengan win rate tertinggi di catatanmu: $bestHero ($hWins/$hGames). Sampel kecil belum tentu mewakili performa sebenarnya.",
                13f, muted, false
            ))
        }
        historyBox.removeAllViews()
        historyBox.addView(text("RIWAYAT PERTANDINGAN", 18f, white, true))
        if (arr.length() == 0) {
            historyBox.addView(text("Belum ada data. Simpan hasil match pertamamu.", 14f, muted, false))
        } else {
            val dateFmt = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
            for (i in arr.length() - 1 downTo 0) {
                val x = arr.optJSONObject(i) ?: continue
                val win = x.optBoolean("win")
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 10, 12, 10)
                    setBackgroundColor(panel)
                }
                val label = if (win) "MENANG" else "KALAH"
                row.addView(text("${x.optString("hero")} • $label", 15f, if (win) green else red, true))
                row.addView(text(
                    "${x.optString("role")} • ${x.optInt("duration")} menit • K/D/A ${x.optInt("kills")}/${x.optInt("deaths")}/${x.optInt("assists")}",
                    13f, muted, false
                ))
                row.addView(text(dateFmt.format(Date(x.optLong("time"))), 12f, muted, false))
                historyBox.addView(row, lp().apply { bottomMargin = 7 })
            }
        }
        val clear = Button(this).apply {
            text = "Hapus semua data lokal"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().clear().apply()
                refreshAll()
            }
        }
        historyBox.addView(clear)
    }

    private fun avg(value: Int, total: Int): String =
        if (total == 0) "0.0" else String.format(Locale.getDefault(), "%.1f", value.toDouble() / total)

    private fun card(parent: LinearLayout): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
        }
        parent.addView(box, lp().apply { bottomMargin = 14 })
        return box
    }

    private fun edit(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(muted)
        setTextColor(white)
        textSize = 15f
        inputType = if (hintText.startsWith("Nama")) android.text.InputType.TYPE_CLASS_TEXT
                    else android.text.InputType.TYPE_CLASS_NUMBER
        setPadding(10, 7, 10, 7)
        backgroundTintList = android.content.res.ColorStateList.valueOf(red)
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 5, 0, 5)
    }

    private fun lp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun TextView.margins(l: Int, t: Int, r: Int, b: Int): TextView {
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(l, t, r, b) }
        return this
    }
}
